#!/bin/sh
#	Chat to get to a PPP system...

#
# 	FIXME: Is there a better way to figure out what folder I'm in?
#
PPPHOST=`(cd /etc/ppp/hosts ; for x in * ; do 
	echo -n ""
	if [ "/etc/ppp/hosts/${x}/../../chat.sh" = "$0" ]; then 
		echo ${x}; 
	fi 
done)`

/usr/local/bin/chat -f /etc/ppp/hosts/${PPPHOST}/chat.script 

RETVAL=$?

if [ "$RETVAL" = 0 ]; then
#
#	FIXME: There must be a better way to do this...
#
	(echo `/bin/date | awk '{print $2,$3,$4}'` `/bin/hostname` "chat.sh[$$]" "Connected to ${PPPHOST}" > /dev/console 2>&1)
fi

exit $RETVAL
